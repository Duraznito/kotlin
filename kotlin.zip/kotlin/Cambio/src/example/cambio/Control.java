package example.cambio;

import android.os.Bundle;
import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Control extends Activity {
	private EditText folio;
	private TextView fol,moneda ,total;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_control);
		folio= (EditText)findViewById(R.id.editText1);
		fol = (TextView)findViewById(R.id.textView2);
		moneda= (TextView)findViewById(R.id.textView3);
		total= (TextView)findViewById(R.id.textView4);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.control, menu);
		return true;
	}
	public void buscar (View view){
	
	   	AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "admin", null, 1);
    	SQLiteDatabase base = admin.getWritableDatabase();
    	
    	String dni = folio.getText().toString();
    	Cursor fila = base.rawQuery("select folio, moneda, total from  registro where folio=" + dni, null);
    	if(fila.moveToFirst()){
    		fol.setText(fila.getString(0));
    		moneda.setText(fila.getString(1));
    		total.setText(fila.getString(2));
    	}
    
	}

}
