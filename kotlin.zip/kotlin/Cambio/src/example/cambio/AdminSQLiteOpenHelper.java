package example.cambio;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AdminSQLiteOpenHelper extends SQLiteOpenHelper{

	public AdminSQLiteOpenHelper(Context context, String name,
		CursorFactory factory, int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public void onCreate(SQLiteDatabase base) {
		// TODO Auto-generated method stub
		base.execSQL("create table cambio (idmone integer primary key ,moneda txt ,precio double)");
		base.execSQL("create table registro (folio integer primary key ,moneda txt ,total double)");
		
		base.execSQL("create table bodega (ID integer primary key ," +
				                          "Nombre txt ," +
				                          "Cantidad double" +
				                          "Precio   double)");
	}

	@Override
	public void onUpgrade(SQLiteDatabase base, int arg1, int arg2) {
		// TODO Auto-generated method stub
		base.execSQL("drop table if exists cambio");
		base.execSQL("drop table if exists registro");
		base.execSQL("create table cambio (idmone integer primary key ,moneda txt ,precio double)");
		base.execSQL("create table registro (folio integer primary key ,moneda txt ,total double)");
	
		base.execSQL("drop table if exists bodega");
		base.execSQL("create table bodega (ID integer primary key ," +
				                          "Nombre txt ," +
				                          "Cantidad double" +
				                          "Precio   double)");
	}

	

}
