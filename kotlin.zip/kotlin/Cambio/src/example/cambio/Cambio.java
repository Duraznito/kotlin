package example.cambio;



import android.os.Bundle;
import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Cambio extends Activity {
	private EditText idc,camb;
	private TextView moneda, precio,resu1,folio;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cambio);
	    idc= (EditText)findViewById(R.id.editText1);
		moneda = (TextView)findViewById(R.id.textView1);
		precio= (TextView)findViewById(R.id.textView2);
		camb= (EditText)findViewById(R.id.editText2);
		resu1=(TextView)findViewById(R.id.textView3);
		folio=(TextView)findViewById(R.id.textView6);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.cambio, menu);
		return true;
	}
	public void Buscar (View view){
		double a= 0.0 ;
		String b;
	   	AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "admin", null, 1);
    	SQLiteDatabase base = admin.getWritableDatabase();
    	
    	String dni = idc.getText().toString();
    	Cursor fila = base.rawQuery("select moneda, precio from cambio where idmone=" + dni, null);
    	if(fila.moveToFirst()){
    		moneda.setText(fila.getString(0));
    		precio.setText(fila.getString(1));
    	}
    	a= (int)( Math.random()*100);
    	  b=String.valueOf(a);
    	folio.setText(b);
	}
	
	public void cambiar(View view){
		 String d1,d2,r;
		    double ope1=0.0,ope2=0.0,res=0.0;
		    
		  d1= camb.getText().toString();
  	    d2= precio.getText().toString();
  	    ope1=Double.parseDouble(d1);
  	    ope2=Double.parseDouble(d2);
  	    res=ope1*ope2;
  	    r=String.valueOf(res);
   	resu1.setText(r);
  	
  	
		
	}
	public void guardar (View View){
      	AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "admin", null, 1);
    	SQLiteDatabase base = admin.getWritableDatabase();
    	
    	ContentValues datos = new ContentValues();
    	
    	datos.put("moneda", moneda.getText().toString());
    	datos.put("total", resu1.getText().toString());
    	datos.put("folio", folio.getText().toString());
    	
    	
    	
    	base.insert("registro", null, datos);
    	base.close();
    	
    	moneda.setText("");
    	resu1.setText("");
        folio.setText("");
        idc.setText("");
        precio.setText("");
        camb.setText("");
    	
    	
    	Toast.makeText(this, "Datos guardados", Toast.LENGTH_SHORT).show();
    }
	}


