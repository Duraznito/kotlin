/** Automatically generated file. DO NOT MODIFY */
package example.cambio;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}