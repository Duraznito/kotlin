/**
 paquete del proyecto general
 */
package ingresando.datos


 /**
 funcion principal de la clase
 */

fun main(arg: Array<String>) {
	 
 /**
 variables (en este caso es un arreglo llamado numeros)
 */
	 
   val numeros: IntArray 
    numeros = IntArray(10)
	
	 
 /**
 divisor
 */
  println("------------------------")
	
	 
  /**
 variables (en este caso es un arreglo llamado numeros) ademas toma los datos y los almacena en el arreglo
 */
	 
    for(i in 0..9) {
        print("Ingrese Numero "+ (i+1) +";")
        numeros[i] = readLine()!!.toInt()
    }
	 
	 

	 
  println("------------------------")	
/**
compara con el 0 para verificar numeros negativos 
 */
	 for(i in 0..9) {
	   if(numeros[i] < 0){
	    println("es negativo; " + numeros[i])
     	}
	 }
	  println("------------------------")
	
	 
 /**
 compara con 0 para numeros positivos 
 */
	 
	 for(i in 0..9) {
	   if(numeros[i] > 0){
	    println("es Positivo; " + numeros[i])
     	}
	 }
	  println("------------------------")
	
 /**
 compara que los numeros de la lista divididos entre 5 me den 0 para saber si es multiplo de 5 
 */
	 
	 
	 
	 for(i in 0..9) {
	   if(numeros[i]  % 5 == 0){
	    println("es Multiplo de 5; " + numeros[i])
     	}
	 }
	
	
	 println("------------------------")
	 
	 
/**
 
 */
	 
	var Suma:Int
	Suma = 0
	
	for(i in 0..9) {
	
	   if(numeros[i]  % 2 == 0){
	    println("es Multiplo de 2; " + numeros[i])
		  Suma=(Suma + numeros[i])
     	}
	  	
	 }
	 println("La suma de los pares es; " + Suma)
	
	
	println("------------------------")
	println(">>lista ingresada")
     for(i in 0..9) {
        println(numeros[i])
    }
	
	
	
	
}
